const projects = [
    {
        title: "Project 1",
        description: "JavaScript Assignment.",
        image: "bg-img4.jpg"
    },
    {
        title: "Project 2",
        description: "Bio Data.",
        image: "bg-img7.jpg"
    },
    {
        title: "Project 3",
        description: "my journey about creating this project.",
        image: "bg-img3.jpg"
    }
];


function showAlert() {
    alert('Thank you for visiting my portfolio!');
}
